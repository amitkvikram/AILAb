#include<bits/stdc++.h>
using namespace std;

typedef vector<int> vi;

int main(){
    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 100; j++){
            cout << i << " " << i + 1 << " "<<100 << endl;
        }
    }
    return 0;
}